﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JXHighWay.WatchHouse.Bll.Server
{
    public class PowerSwitchInfo
    {
        public int ID { get; set; }
        public int DianYuanID { get; set; }
        public string LuHao { get; set; }
        public string MinCheng { get; set; }
        public string LeiXing { get; set; }
    }
}
