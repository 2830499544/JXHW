﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JXHighWay.WatchHouse.Bll.Server
//{
//    public class SendCMDModel
//    {
//        /// <summary>
//        /// 岗亭ID
//        /// </summary>
//        public int GangTingID { get; set; }

//        public byte ID_H { get; set; }

//        public byte ID_L { get; set; }

//        public byte CMD { get; set; }

//        public byte SUB { get; set; }

//        public short SN { get; set; }
//        /// <summary>
//        /// 是否回复
//        /// </summary>
//        public bool State { get; set; }
//        public bool IsSend { get; set; }
//    }
//}
