﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JXHighWay.WatchHouse.Bll.Client.GanTing
{
    /// <summary>
    /// 灯光状态
    /// </summary>
    public class DengGuanStateInfo
    {
        public bool IsOpen { get; set; }
        public int LianDu { get; set; }
    }
}
