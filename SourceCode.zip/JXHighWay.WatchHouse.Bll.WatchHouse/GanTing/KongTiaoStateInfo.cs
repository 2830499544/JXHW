﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JXHighWay.WatchHouse.Bll.Client.GanTing
{
    public class KongTiaoStateInfo
    {
        public bool IsOpen { get; set; }
        public short ShiLeiWD { get; set; }

        public string FengShu { get; set; }
        public string MoShi { get; set; }
    }
}
